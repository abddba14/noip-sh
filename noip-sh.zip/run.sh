#!/bin/bash

INTERVAL=1200

while :
do

echo $(date)
./noipupdater.sh -c /sdcard/tmp/noip.cfg
echo
if [ $INTERVAL -eq 0 ]
then
break
else sleep "$INTERVAL"
fi

done

exit 0
